#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.IO;

public static class GlentProjectSetup
{
    public const string ScenePath = "Assets/Scenes/GLENT_Main.unity";
    public const string PipelinePath = "Assets/Settings/GLENT_URP.asset";

    [MenuItem("GLENT/Generate starter scene and URP assets")]
    public static void Generate()
    {
        EnsureFolder("Assets/Settings");
        EnsureFolder("Assets/Scenes");

        var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
        if (pipeline == null)
        {
            pipeline = ScriptableObject.CreateInstance<UniversalRenderPipelineAsset>();
            AssetDatabase.CreateAsset(pipeline, PipelinePath);
        }
        pipeline.supportsHDR = true;
        pipeline.msaaSampleCount = 4;
        pipeline.renderScale = 1f;
        GraphicsSettings.defaultRenderPipeline = pipeline;
        QualitySettings.renderPipeline = pipeline;

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var root = new GameObject("GLENT Bootstrap");
        root.AddComponent<GlentBootstrap>();
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("GLENT starter scene and URP pipeline created.");
    }

    public static void EnsureGenerated()
    {
        if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null || AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath) == null)
            Generate();
        else
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
    }

    private static void EnsureFolder(string path)
    {
        if (AssetDatabase.IsValidFolder(path)) return;
        var parent = Path.GetDirectoryName(path).Replace("\\", "/");
        var name = Path.GetFileName(path);
        if (!AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
        AssetDatabase.CreateFolder(parent, name);
    }
}
#endif
