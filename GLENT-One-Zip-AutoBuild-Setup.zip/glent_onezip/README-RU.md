# GLENT — сборка Android APK из одного ZIP

## Как это работает
После однократной установки workflow в GitHub-репозиторий достаточно загружать в корень репозитория один ZIP-файл с Unity-проектом. GitHub Actions заметит ZIP, безопасно распакует его, найдёт папку Unity-проекта и запустит сборку APK. Готовый APK появится в Actions → запуск сборки → Artifacts.

## Важно: однократная настройка
GitHub не запускает workflow, который находится внутри ещё не распакованного ZIP. Поэтому сначала нужно один раз добавить файл `.github/workflows/build-from-zip.yml` в репозиторий. После этого обновления проекта можно загружать одним ZIP.

Самый простой вариант: пришлите ссылку на ваш GitHub-репозиторий, и workflow можно будет добавить туда напрямую через подключённый GitHub. Либо распакуйте этот setup-архив и добавьте файл workflow в репозиторий по указанному пути.

## Секреты Unity (один раз)
В Settings → Secrets and variables → Actions → New repository secret добавьте:
- `UNITY_LICENSE` — содержимое файла лицензии Unity `.ulf`;
- `UNITY_EMAIL` — email аккаунта Unity;
- `UNITY_PASSWORD` — пароль аккаунта Unity.

Не публикуйте эти значения в файлах репозитория и не отправляйте их в чат.

## Загрузка ZIP проекта
1. Откройте корень GitHub-репозитория.
2. Add file → Upload files.
3. Загрузите ZIP с Unity-проектом (например, `GLENT-VPN-Pitbike-Unity-Stage3-Android.zip`) как один файл в корень.
4. Нажмите Commit changes.
5. Откройте Actions. Workflow `Build Android APK from one ZIP` должен запуститься автоматически.
6. После успешного запуска откройте его страницу и скачайте `GLENT-Pitbike-Android-APK` из Artifacts.

## Требования к ZIP
Внутри архива должна быть папка Unity-проекта с `Assets/`, `Packages/` и `ProjectSettings/`. Допускается одна или несколько внешних папок-обёрток. Проект GLENT Stage 3 уже содержит метод сборки `GlentAndroidBuild.Build`.

Workflow рассчитан на Unity `2022.3.62f1`, Android ARM64/IL2CPP настройки проекта и Unity Personal license. Сборка не гарантируется до успешного запуска Actions: возможны ошибки лицензии, несовместимости пакетов или исходников.
