# GLENT VPN PITBIKE STUNT — Unity gameplay prototype

Unity 2022.3 LTS / URP 14. This update adds a playable arcade pitbike prototype:
- Rigidbody bike handling, throttle, steering, brake and air-control trick input
- Follow / close chase / rider camera modes
- Procedural riding area, dirt jumps, berms, ruts, rocks, pine trees and distant hills
- Bike and rider placeholder meshes with metallic and rubber materials
- Mobile touch HUD, pause, speed, score and best score
- Low / Medium / High / Ultra runtime quality settings from GlentGraphicsSettings

## Open and generate the scene
1. Open with Unity 2022.3 LTS (prefer 2022.3.62f1).
2. Wait for URP package import.
3. In the Unity menu choose GLENT > Generate starter scene and URP assets.
4. Open Assets/Scenes/GLENT_Main.unity and press Play.
5. For Android, install Android Build Support, SDK & NDK Tools, and OpenJDK in Unity Hub.

## Controls
- Keyboard: W/Up throttle, A/D steer, Space brake, Left Shift trick.
- Touchscreen: on-screen throttle, steering, brake and trick controls.
- CAMERA cycles between three camera positions. PAUSE pauses the game.

## Important limitations
This is a more complete playable prototype, not a finished photorealistic commercial game. The bike/rider and environment are procedural placeholder geometry. True photorealism requires authored/licensed high-poly models, PBR texture sets, skeletal rider animation, authored terrain/vegetation, spatial audio, VFX, device profiling and extensive playtesting. URP HDR, shadows and MSAA depend on the actual URP asset, GPU and Android device; 120 FPS is a target, not a guarantee. Test thermals and frame pacing on the target phone.

The game has not been opened or compiled in the Unity Editor in this environment. Treat this ZIP as source project files, not a verified APK.


## Этап 2 — детализация и управление
В этом обновлении добавлены процедурные детали питбайка: перекрёстные спицы, внедорожные грунтозацепы, тормозные роторы и суппорты, цепь и звёзды, выпускная система, элементы радиаторов, подножки, вилочные ноги и задняя пружина амортизатора. Контроллер получил настройку центра масс, боковое сцепление, наклон в повороте, ограничение скорости по горизонтальной составляющей и усиление воздушного управления. Камера плавно расширяет угол обзора с ростом скорости.

Важно: геометрия создаётся примитивами Unity во время запуска — это более детализированный игровой прототип, а не готовая высокополигональная модель. Физика — упрощённая Rigidbody-модель, не симуляция отдельных колёс и подвесок. Исходники здесь не были скомпилированы в Unity Editor в этой среде; откройте проект в Unity 2022.3 LTS и проверьте Console перед сборкой APK.

## Этап 3 — автоматическая сборка APK через GitHub Actions

В проект добавлен workflow `.github/workflows/build-android.yml`. Он собирает Android APK в облаке GitHub Actions без установки Unity на телефон или ПК. Сборка запускается вручную через вкладку **Actions → Build GLENT Android APK → Run workflow**, а также автоматически при изменениях в `Assets`, `Packages` или `ProjectSettings` в ветках `main`/`master`.

### Однократная настройка Unity Personal — можно сделать с телефона

1. После загрузки файлов проекта в GitHub откройте **Actions → Request Unity Personal activation file → Run workflow**.
2. Дождитесь завершения и скачайте из Artifacts архив `Unity-activation-file`. Внутри будет файл `.alf`.
3. Откройте [Unity License Manual Activation](https://license.unity3d.com/manual), загрузите `.alf` и следуйте шагам сайта, чтобы получить `.ulf`. Доступность ручной активации Personal зависит от текущего процесса Unity; если портал не предлагает Personal, не обходите ограничения — пришлите текст/скриншот ошибки.
4. В GitHub откройте репозиторий → **Settings → Secrets and variables → Actions → New repository secret**. Создайте `UNITY_LICENSE` и вставьте в него всё содержимое `.ulf`.
5. Создайте ещё два secrets: `UNITY_EMAIL` (почта Unity ID) и `UNITY_PASSWORD` (пароль Unity ID). Не отправляйте эти данные в чат и не добавляйте их в файлы проекта.
6. Запустите **Actions → Build GLENT Android APK → Run workflow**. После успешной сборки скачайте `GLENT-Pitbike-Android-APK` в разделе Artifacts.

Секреты нужны только в настройках репозитория; их не должно быть в открытом коде. Если у тебя уже есть действующий `.ulf`, шаги 1–3 можно пропустить.

### Параметры APK

- Android APK (не AAB), ARM64, IL2CPP
- Package ID: `com.glentvpn.pitbike`
- Минимальная версия Android: API 26 (Android 8.0)
- Альбомная ориентация

### Важно

Этот workflow и Editor build script добавлены в исходники, но не запускались здесь в GitHub Actions и APK не проверен на реальном телефоне. Первая сборка может завершиться ошибкой из-за лицензии Unity, недоступности Android-модуля/образа GameCI или ошибок импорта проекта. Если это произойдёт, пришлите текст ошибки из лога Actions — по нему можно исправить конкретную причину. Для публикации в Google Play потребуется отдельная настройка release-подписи; текущий APK предназначен для тестовой установки.
