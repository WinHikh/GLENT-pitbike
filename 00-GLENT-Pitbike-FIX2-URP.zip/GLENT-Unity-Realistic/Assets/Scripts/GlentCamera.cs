using UnityEngine;

[RequireComponent(typeof(Camera))]
public class GlentCamera : MonoBehaviour
{
    public int Mode { get; private set; } = 0;
    Transform target;
    Vector3 velocity;
    Camera cameraComponent;
    void Awake() { cameraComponent = GetComponent<Camera>(); }
    void LateUpdate()
    {
        if (!target)
        {
            var bike = FindObjectOfType<GlentBikeController>();
            if (bike) target = bike.transform;
            if (!target) return;
        }
        var controller = target.GetComponent<GlentBikeController>();
        float speed = controller ? controller.Speed : 0f;
        Vector3 offset = Mode == 0 ? new Vector3(0, 3.2f, -6.8f) :
                         Mode == 1 ? new Vector3(0, 1.6f, -3.2f) : new Vector3(0, 1.28f, .35f);
        Vector3 desired = target.TransformPoint(offset);
        transform.position = Vector3.SmoothDamp(transform.position, desired, ref velocity, Mode == 2 ? .08f : .16f);
        Quaternion look = Mode == 2 ? target.rotation :
            Quaternion.LookRotation(target.position + Vector3.up * .8f - transform.position);
        transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * 7f);
        if (cameraComponent)
            cameraComponent.fieldOfView = Mathf.Lerp(cameraComponent.fieldOfView, 68f + Mathf.Clamp(speed / 25f, 0f, 1f) * 7f, Time.deltaTime * 2.5f);
    }
    public void NextMode() { Mode = (Mode + 1) % 3; }
}
