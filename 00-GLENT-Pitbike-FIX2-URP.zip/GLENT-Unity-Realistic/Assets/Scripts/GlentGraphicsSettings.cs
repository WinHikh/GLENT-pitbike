using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

/// <summary>Runtime graphics presets for flagship Android devices.</summary>
public class GlentGraphicsSettings : MonoBehaviour
{
    public enum Preset { Low, Medium, High, Ultra }
    public static GlentGraphicsSettings Instance { get; private set; }
    public Preset CurrentPreset { get; private set; }

    [Header("Optional URP pipeline asset assigned in Inspector")]
    [SerializeField] private UniversalRenderPipelineAsset urpAsset;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        Apply(DetectRecommendedPreset());
    }

    public Preset DetectRecommendedPreset()
    {
        // Never assume every phone with a high-end label has the same GPU budget.
        int memory = SystemInfo.systemMemorySize;
        int gpu = SystemInfo.graphicsMemorySize;
        int cores = SystemInfo.processorCount;
        if (SystemInfo.graphicsDeviceType == GraphicsDeviceType.Null) return Preset.Low;
        if (memory >= 10000 && gpu >= 1500 && cores >= 8) return Preset.Ultra;
        if (memory >= 7000 && gpu >= 900 && cores >= 8) return Preset.High;
        if (memory >= 4500 && cores >= 6) return Preset.Medium;
        return Preset.Low;
    }

    public void Apply(Preset preset)
    {
        CurrentPreset = preset;
        int targetFps = preset == Preset.Ultra ? 120 : preset == Preset.High ? 90 : 60;
        Application.targetFrameRate = targetFps;
        QualitySettings.vSyncCount = 0;
        QualitySettings.antiAliasing = preset == Preset.Ultra ? 8 : preset == Preset.High ? 4 : preset == Preset.Medium ? 2 : 0;
        QualitySettings.shadowResolution = (int)preset >= (int)Preset.High ? UnityEngine.ShadowResolution.VeryHigh : preset == Preset.Medium ? UnityEngine.ShadowResolution.High : UnityEngine.ShadowResolution.Low;
        QualitySettings.shadows = preset == Preset.Low ? UnityEngine.ShadowQuality.HardOnly : UnityEngine.ShadowQuality.All;
        QualitySettings.shadowDistance = preset == Preset.Ultra ? 180f : preset == Preset.High ? 130f : preset == Preset.Medium ? 75f : 35f;
        QualitySettings.shadowCascades = (int)preset >= (int)Preset.High ? 4 : 2;
        QualitySettings.anisotropicFiltering = (int)preset >= (int)Preset.High ? AnisotropicFiltering.ForceEnable : AnisotropicFiltering.Enable;
        QualitySettings.masterTextureLimit = preset == Preset.Ultra ? 0 : preset == Preset.High ? 0 : preset == Preset.Medium ? 1 : 2;
        QualitySettings.lodBias = preset == Preset.Ultra ? 2.5f : preset == Preset.High ? 2f : preset == Preset.Medium ? 1.2f : 0.7f;
        QualitySettings.maximumLODLevel = preset == Preset.Ultra ? 0 : preset == Preset.High ? 0 : preset == Preset.Medium ? 1 : 2;
        if (urpAsset != null)
        {
            urpAsset.renderScale = preset == Preset.Ultra ? 1.15f : preset == Preset.High ? 1.0f : preset == Preset.Medium ? 0.9f : 0.75f;
            urpAsset.msaaSampleCount = preset == Preset.Ultra ? 8 : preset == Preset.High ? 4 : preset == Preset.Medium ? 2 : 1;
            urpAsset.supportsHDR = (int)preset >= (int)Preset.High;
            urpAsset.shadowDistance = QualitySettings.shadowDistance;
        }
        PlayerPrefs.SetInt("GLENT_GRAPHICS_PRESET", (int)preset);
        PlayerPrefs.Save();
    }

    public void SetPreset(int value) => Apply((Preset)Mathf.Clamp(value, 0, 3));
}
