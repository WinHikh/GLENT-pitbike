using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class GlentBikeController : MonoBehaviour
{
    [Header("Powertrain")]
    public float acceleration = 30f;
    public float maxSpeed = 25f;
    public float brakePower = 22f;
    [Header("Handling")]
    public float steering = 78f;
    public float leanTorque = 5.5f;
    public float lateralGrip = 4.8f;
    public float airControl = 2.8f;
    public float downforce = 2.2f;

    Rigidbody rb;
    float throttle, steer;
    bool brake, trick;
    public float Speed => rb ? rb.velocity.magnitude * 3.6f : 0f;
    public bool IsGrounded => Physics.Raycast(transform.position + Vector3.up * .12f, Vector3.down, 1.2f);

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.centerOfMass = new Vector3(0, -.22f, -.08f);
        rb.maxAngularVelocity = 8f;
    }

    void Update()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        steer = Mathf.Abs(h) > .05f ? h : GlentMobileHUD.Steer;
        throttle = Mathf.Abs(v) > .05f ? Mathf.Max(0, v) : GlentMobileHUD.Throttle;
        brake = Input.GetKey(KeyCode.Space) || GlentMobileHUD.Brake;
        trick = Input.GetKey(KeyCode.LeftShift) || GlentMobileHUD.Trick;
    }

    void FixedUpdate()
    {
        bool grounded = IsGrounded;
        Vector3 localVelocity = transform.InverseTransformDirection(rb.velocity);
        float forwardSpeed = Mathf.Max(0f, localVelocity.z);

        if (grounded)
        {
            if (throttle > 0f && forwardSpeed < maxSpeed)
                rb.AddForce(transform.forward * throttle * acceleration, ForceMode.Acceleration);

            if (brake)
                rb.AddForce(-transform.forward * brakePower, ForceMode.Acceleration);

            // Reduce unrealistic sideways skating while retaining controlled dirt-bike slides.
            Vector3 lateral = transform.right * localVelocity.x;
            rb.AddForce(-lateral * lateralGrip, ForceMode.Acceleration);

            float speedFactor = Mathf.Clamp01(forwardSpeed / 2.5f);
            rb.AddTorque(Vector3.up * steer * steering * speedFactor * .012f, ForceMode.Acceleration);

            // Lean into turns, then let the bike naturally recover upright.
            float targetLean = -steer * Mathf.Clamp01(forwardSpeed / 7f) * 22f;
            float currentLean = Vector3.SignedAngle(transform.up, Vector3.up, transform.forward);
            rb.AddTorque(transform.forward * ((targetLean - currentLean) * leanTorque * .035f), ForceMode.Acceleration);
            rb.AddForce(-transform.up * downforce * forwardSpeed, ForceMode.Acceleration);
        }
        else
        {
            float multiplier = trick ? 1.8f : 1f;
            rb.AddTorque(transform.right * (-steer * airControl * multiplier), ForceMode.Acceleration);
            rb.AddTorque(transform.forward * (-Input.GetAxisRaw("Vertical") * airControl), ForceMode.Acceleration);
        }

        Vector3 horizontal = new Vector3(rb.velocity.x, 0f, rb.velocity.z);
        if (horizontal.magnitude > maxSpeed)
        {
            Vector3 limited = horizontal.normalized * maxSpeed;
            rb.velocity = new Vector3(limited.x, rb.velocity.y, limited.z);
        }
    }

    public void ResetBike()
    {
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        transform.position = new Vector3(0, 1.1f, 3);
        transform.rotation = Quaternion.identity;
    }
}
