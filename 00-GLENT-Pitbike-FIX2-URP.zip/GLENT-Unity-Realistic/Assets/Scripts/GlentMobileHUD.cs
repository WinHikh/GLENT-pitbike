using UnityEngine;
public class GlentMobileHUD : MonoBehaviour
{
    public static float Throttle,Steer; public static bool Brake,Trick;
    GUIStyle big,small,button; GlentBikeController bike; GlentCamera cam; bool paused;
    void Start(){big=new GUIStyle(GUI.skin.label){fontSize=26,fontStyle=FontStyle.Bold,normal={textColor=Color.white}};small=new GUIStyle(GUI.skin.label){fontSize=15,normal={textColor=Color.white}};button=new GUIStyle(GUI.skin.button){fontSize=18,fontStyle=FontStyle.Bold};}
    void OnGUI(){
        if(!bike)bike=FindObjectOfType<GlentBikeController>();if(!cam)cam=FindObjectOfType<GlentCamera>();
        float scale=Screen.width/900f;GUI.matrix=Matrix4x4.TRS(Vector3.zero,Quaternion.identity,Vector3.one*Mathf.Clamp(scale,.65f,1.5f));
        GUI.Label(new Rect(22,18,300,42),"GLENT  /  PITBIKE",big);
        GUI.Label(new Rect(24,60,300,30),$"SCORE  {GlentGameManager.Instance?.Score ?? 0}     BEST  {GlentGameManager.Instance?.Best ?? 0}",small);
        GUI.Label(new Rect(Screen.width/scale-190,22,180,40),$"{(bike?bike.Speed:0):0} KM/H",big);
        if(GUI.Button(new Rect(Screen.width/scale-145,75,125,42),"CAMERA"))cam?.NextMode();
        float y=Screen.height/scale-145;
        HoldButton(new Rect(28,y,130,105),"BRAKE",EventType.MouseDown,()=>Brake=true,()=>Brake=false);
        HoldButton(new Rect(Screen.width/scale-320,y,130,105),"LEFT",EventType.MouseDown,()=>Steer=-1,()=>{if(Steer<0)Steer=0;});
        HoldButton(new Rect(Screen.width/scale-175,y,130,105),"RIGHT",EventType.MouseDown,()=>Steer=1,()=>{if(Steer>0)Steer=0;});
        HoldButton(new Rect(Screen.width/scale-320,y-118,275,100),"THROTTLE",EventType.MouseDown,()=>Throttle=1,()=>Throttle=0);
        HoldButton(new Rect(175,y,130,105),"TRICK",EventType.MouseDown,()=>Trick=true,()=>Trick=false);
        if(GUI.Button(new Rect(Screen.width/scale-145,125,125,42),paused?"RESUME":"PAUSE")){paused=!paused;Time.timeScale=paused?0:1;}
        if(paused)GUI.Label(new Rect(Screen.width/scale/2-100,Screen.height/scale/2-30,250,60),"PAUSED",big);
    }
    void HoldButton(Rect r,string label,EventType unused,System.Action down,System.Action up){
        var e=Event.current;bool hit=r.Contains(e.mousePosition);
        if(e.type==EventType.MouseDown&&hit){down();e.Use();}
        if(e.type==EventType.MouseUp){up();}
        if(GUI.Button(r,label)){ }
        if(Input.touchCount>0){foreach(Touch t in Input.touches){Vector2 p=new Vector2(t.position.x/Mathf.Clamp(Screen.width/900f,.65f,1.5f),(Screen.height-t.position.y)/Mathf.Clamp(Screen.width/900f,.65f,1.5f));if(r.Contains(p)){if(t.phase==TouchPhase.Began)down();if(t.phase==TouchPhase.Ended||t.phase==TouchPhase.Canceled)up();}}}
    }
    void OnDisable(){Time.timeScale=1;Throttle=Steer=0;Brake=Trick=false;}
}
