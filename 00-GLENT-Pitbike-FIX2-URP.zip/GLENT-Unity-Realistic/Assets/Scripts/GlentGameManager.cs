using UnityEngine;
public class GlentGameManager : MonoBehaviour
{
    public static GlentGameManager Instance; public int Score{get;private set;} public int Best=>PlayerPrefs.GetInt("GLENT_BEST",0);
    GlentBikeController bike; bool airborne; float airTime; Vector3 lastPos; float combo;
    void Awake(){Instance=this;}
    void Update(){
        if(!bike)bike=FindObjectOfType<GlentBikeController>(); if(!bike)return;
        bool air=!bike.IsGrounded;
        if(air&&!airborne){airTime=0;lastPos=bike.transform.position;combo=0;}
        if(air){airTime+=Time.deltaTime;combo+=Mathf.Abs(bike.transform.eulerAngles.z)*.015f;}
        if(!air&&airborne&&airTime>.35f){
            int pts=Mathf.RoundToInt(airTime*100+combo*30);Score+=pts;
            if(Score>Best)PlayerPrefs.SetInt("GLENT_BEST",Score);
        }
        airborne=air;
        if(bike.transform.position.y < -5 || bike.transform.position.z < -10)bike.ResetBike();
    }
    public float AirTime=>airTime;
}
