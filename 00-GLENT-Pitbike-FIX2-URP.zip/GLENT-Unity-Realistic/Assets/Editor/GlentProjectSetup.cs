#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.IO;

public static class GlentProjectSetup
{
    public const string ScenePath = "Assets/Scenes/GLENT_Main.unity";
    public const string PipelinePath = "Assets/Settings/GLENT_URP.asset";
    public const string RendererPath = "Assets/Settings/GLENT_Renderer.asset";

    [MenuItem("GLENT/Generate starter scene and URP assets")]
    public static void Generate()
    {
        EnsureFolder("Assets/Settings");
        EnsureFolder("Assets/Scenes");

        var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath);
        if (renderer == null)
        {
            renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
            AssetDatabase.CreateAsset(renderer, RendererPath);
        }

        var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
        if (pipeline == null)
        {
            pipeline = ScriptableObject.CreateInstance<UniversalRenderPipelineAsset>();
            AssetDatabase.CreateAsset(pipeline, PipelinePath);
        }

        // A URP asset created with CreateInstance has no renderer assigned by default.
        // Assign a real UniversalRendererData before Unity attempts to create the pipeline.
        var serializedPipeline = new SerializedObject(pipeline);
        var rendererList = serializedPipeline.FindProperty("m_RendererDataList");
        if (rendererList == null)
            throw new System.Exception("URP setup failed: m_RendererDataList was not found. Check the installed URP package version.");
        rendererList.arraySize = 1;
        rendererList.GetArrayElementAtIndex(0).objectReferenceValue = renderer;
        var defaultRenderer = serializedPipeline.FindProperty("m_DefaultRendererIndex");
        if (defaultRenderer != null) defaultRenderer.intValue = 0;
        serializedPipeline.ApplyModifiedPropertiesWithoutUndo();

        pipeline.supportsHDR = true;
        pipeline.msaaSampleCount = 4;
        pipeline.renderScale = 1f;
        EditorUtility.SetDirty(renderer);
        EditorUtility.SetDirty(pipeline);
        GraphicsSettings.defaultRenderPipeline = pipeline;
        QualitySettings.renderPipeline = pipeline;

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var root = new GameObject("GLENT Bootstrap");
        root.AddComponent<GlentBootstrap>();
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("GLENT starter scene and URP pipeline with renderer data created.");
    }

    public static void EnsureGenerated()
    {
        var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
        var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath);
        bool rendererAssigned = false;
        if (pipeline != null)
        {
            var serializedPipeline = new SerializedObject(pipeline);
            var rendererList = serializedPipeline.FindProperty("m_RendererDataList");
            rendererAssigned = renderer != null && rendererList != null && rendererList.arraySize > 0 &&
                rendererList.GetArrayElementAtIndex(0).objectReferenceValue == renderer;
        }

        if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null ||
            pipeline == null || renderer == null || !rendererAssigned)
            Generate();
        else
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
    }

    private static void EnsureFolder(string path)
    {
        if (AssetDatabase.IsValidFolder(path)) return;
        var parent = Path.GetDirectoryName(path).Replace("\\", "/");
        var name = Path.GetFileName(path);
        if (!AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
        AssetDatabase.CreateFolder(parent, name);
    }
}
#endif
