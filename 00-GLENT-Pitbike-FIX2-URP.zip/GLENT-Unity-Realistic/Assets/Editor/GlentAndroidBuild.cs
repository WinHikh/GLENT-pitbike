#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class GlentAndroidBuild
{
    public static void Build()
    {
        GlentProjectSetup.EnsureGenerated();
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);

        PlayerSettings.companyName = "GLENT";
        PlayerSettings.productName = "GLENT VPN Pitbike";
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.glentvpn.pitbike");
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.stripEngineCode = true;
        EditorUserBuildSettings.buildAppBundle = false;

        string projectRoot = Directory.GetParent(Application.dataPath).FullName;
        string repositoryRoot = Directory.GetParent(projectRoot).FullName;
        string output = Path.Combine(repositoryRoot, "build/Android/GLENT-Pitbike.apk");
        Directory.CreateDirectory(Path.GetDirectoryName(output));
        var options = new BuildPlayerOptions
        {
            scenes = new[] { GlentProjectSetup.ScenePath },
            locationPathName = output,
            target = BuildTarget.Android,
            options = BuildOptions.StrictMode
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
            throw new System.Exception("GLENT Android build failed: " + report.summary.result + ". Check the Unity build log.");

        Debug.Log("GLENT APK created: " + output + " | Size: " + report.summary.totalSize + " bytes");
    }
}
#endif
