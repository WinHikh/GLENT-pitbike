using UnityEngine;

/// <summary>One chase camera. Drag in the central upper screen area to orbit the view.</summary>
[RequireComponent(typeof(Camera))]
public class GlentCamera : MonoBehaviour
{
    [Header("Orbit camera")]
    public float distance = 6.6f;
    public float height = 2.75f;
    public float lookHeight = 1.0f;
    public float dragSensitivity = 0.16f;
    public float minPitch = 5f;
    public float maxPitch = 38f;
    public float followSmooth = 0.11f;

    Transform target;
    Vector3 positionVelocity;
    Camera cameraComponent;
    float yaw;
    float pitch = 13f;
    int activeFinger = -1;
    Vector2 previousPointer;
    bool mouseDragging;

    void Awake()
    {
        cameraComponent = GetComponent<Camera>();
        yaw = 0f;
    }

    void Update()
    {
        if (!target)
        {
            var bike = FindObjectOfType<GlentBikeController>();
            if (bike) target = bike.transform;
        }

        // Touch look is deliberately limited to the central/top half of the display,
        // leaving the lower half free for throttle, brake and steering controls.
        if (Input.touchCount > 0)
        {
            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch t = Input.GetTouch(i);
                if (t.phase == TouchPhase.Began && activeFinger == -1 && IsLookZone(t.position))
                {
                    activeFinger = t.fingerId;
                    previousPointer = t.position;
                }
                else if (t.fingerId == activeFinger)
                {
                    if (t.phase == TouchPhase.Moved)
                    {
                        ApplyDrag(t.position - previousPointer);
                        previousPointer = t.position;
                    }
                    else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
                        activeFinger = -1;
                }
            }
        }
        else activeFinger = -1;

#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButtonDown(0) && IsLookZone(Input.mousePosition))
        {
            mouseDragging = true;
            previousPointer = Input.mousePosition;
        }
        if (Input.GetMouseButton(0) && mouseDragging)
        {
            Vector2 now = Input.mousePosition;
            ApplyDrag(now - previousPointer);
            previousPointer = now;
        }
        if (Input.GetMouseButtonUp(0)) mouseDragging = false;
#endif
    }

    bool IsLookZone(Vector2 screenPoint)
    {
        float x = screenPoint.x / Mathf.Max(1, Screen.width);
        float y = screenPoint.y / Mathf.Max(1, Screen.height);
        return x > 0.12f && x < 0.88f && y > 0.48f && y < 0.94f;
    }

    void ApplyDrag(Vector2 delta)
    {
        yaw += delta.x * dragSensitivity;
        pitch = Mathf.Clamp(pitch - delta.y * dragSensitivity, minPitch, maxPitch);
    }

    void LateUpdate()
    {
        if (!target) return;
        var controller = target.GetComponent<GlentBikeController>();
        float speed = controller ? controller.Speed : 0f;

        Quaternion orbit = Quaternion.Euler(pitch, target.eulerAngles.y + yaw, 0f);
        Vector3 focus = target.position + Vector3.up * lookHeight;
        Vector3 desired = focus + orbit * new Vector3(0f, height - lookHeight, -distance);
        transform.position = Vector3.SmoothDamp(transform.position, desired, ref positionVelocity, followSmooth);
        Quaternion look = Quaternion.LookRotation(focus - transform.position, Vector3.up);
        transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * 10f);

        if (cameraComponent)
            cameraComponent.fieldOfView = Mathf.Lerp(cameraComponent.fieldOfView,
                67f + Mathf.Clamp(speed / 32f, 0f, 1f) * 8f, Time.deltaTime * 2.2f);
    }

    public void ResetView()
    {
        yaw = 0f;
        pitch = 13f;
    }
}
