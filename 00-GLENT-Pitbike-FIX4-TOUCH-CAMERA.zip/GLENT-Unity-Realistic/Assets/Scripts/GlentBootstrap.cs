using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.Collections.Generic;
using System.Collections;

public class GlentBootstrap : MonoBehaviour
{
    Material dirt, darkDirt, red, black, metal, rubber, grass, rock, white;
    bool worldReady;
    string startupMessage = "ЗАГРУЗКА ТРАССЫ";

    IEnumerator Start()
    {
        // Render an initial frame before generating hundreds of procedural objects.
        Application.targetFrameRate = 60;
        Input.multiTouchEnabled = true;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        QualitySettings.vSyncCount = 0;
        if (!FindObjectOfType<GlentGraphicsSettings>())
            new GameObject("GLENT Graphics").AddComponent<GlentGraphicsSettings>();

        RenderSettings.ambientMode = AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = new Color(.48f,.60f,.78f);
        RenderSettings.ambientEquatorColor = new Color(.34f,.31f,.27f);
        RenderSettings.ambientGroundColor = new Color(.13f,.11f,.09f);
        RenderSettings.ambientIntensity = 1.15f;
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.ExponentialSquared;
        RenderSettings.fogColor = new Color(.62f,.69f,.76f);
        RenderSettings.fogDensity = .0028f;

        Material skyTemplate = Resources.Load<Material>("GLENT_ProceduralSky");
        Shader skyShader = skyTemplate != null ? skyTemplate.shader : Shader.Find("Skybox/Procedural");
        if (skyShader != null)
        {
            var sky = skyTemplate != null ? new Material(skyTemplate) : new Material(skyShader);
            if (sky.HasProperty("_AtmosphereThickness")) sky.SetFloat("_AtmosphereThickness", 1.15f);
            if (sky.HasProperty("_SkyTint")) sky.SetColor("_SkyTint", new Color(.62f,.72f,.88f));
            if (sky.HasProperty("_GroundColor")) sky.SetColor("_GroundColor", new Color(.30f,.27f,.23f));
            RenderSettings.skybox = sky;
        }

        dirt=Mat(new Color(.30f,.19f,.12f),0,.18f);
        darkDirt=Mat(new Color(.18f,.12f,.08f),0,.12f);
        red=Mat(new Color(.78f,.018f,.025f),.32f,.62f);
        black=Mat(new Color(.012f,.014f,.018f),.1f,.2f);
        metal=Mat(new Color(.42f,.46f,.48f),.82f,.78f);
        rubber=Mat(new Color(.018f,.019f,.02f),0,.12f);
        grass=Mat(new Color(.12f,.22f,.09f),0,.12f);
        rock=Mat(new Color(.28f,.27f,.24f),0,.15f);
        white=Mat(new Color(.9f,.88f,.78f),.1f,.3f);

        BuildLighting();
        var game = new GameObject("GLENT Game Manager");
        game.AddComponent<GlentGameManager>();
        game.AddComponent<GlentMobileHUD>();
        var cam = new GameObject("Main Camera");
        cam.tag="MainCamera";
        var camera = cam.AddComponent<Camera>();
        camera.fieldOfView=68; camera.nearClipPlane=.08f; camera.farClipPlane=450f;
        camera.allowHDR=true; camera.allowMSAA=true;
        cam.AddComponent<AudioListener>();
        cam.AddComponent<GlentCamera>();

        yield return null; // Render a loading frame before constructing the bike.
        startupMessage = "СОЗДАЁМ МОТОЦИКЛ";
        BuildBike();
        yield return null;
        startupMessage = "СОЗДАЁМ ТРАССУ";
        yield return StartCoroutine(BuildWorldRoutine());
        worldReady = true;
        startupMessage = "";
    }

    void OnGUI()
    {
        if (worldReady || string.IsNullOrEmpty(startupMessage)) return;
        var style = new GUIStyle(GUI.skin.label);
        style.alignment = TextAnchor.MiddleCenter;
        style.fontSize = Mathf.Max(20, Screen.width / 28);
        style.fontStyle = FontStyle.Bold;
        style.normal.textColor = Color.white;
        GUI.Label(new Rect(0, Screen.height * .78f, Screen.width, 60), startupMessage, style);
    }

    Material Mat(Color c,float m,float s)
    {
        Material template = Resources.Load<Material>("GLENT_URP_Lit");
        if (template == null) template = Resources.Load<Material>("GLENT_URP_Unlit");
        Shader sh = template != null ? template.shader : Shader.Find("Universal Render Pipeline/Lit");
        if(sh==null) sh=Shader.Find("Universal Render Pipeline/Unlit");
        if(sh==null) sh=Shader.Find("Unlit/Color");
        if(sh==null) sh=Shader.Find("Hidden/InternalErrorShader");
        if(sh==null) { Debug.LogError("GLENT: no compatible runtime shader found."); return null; }
        var x = template != null ? new Material(template) : new Material(sh);
        x.color=c;
        if(x.HasProperty("_Metallic"))x.SetFloat("_Metallic",m);
        if(x.HasProperty("_Smoothness"))x.SetFloat("_Smoothness",s);
        return x;
    }
    void BuildLighting(){
        var sun=new GameObject("Late afternoon sun").AddComponent<Light>();sun.type=LightType.Directional;sun.intensity=1.45f; sun.color=new Color(1f,.82f,.66f);
        sun.transform.rotation=Quaternion.Euler(34,-32,0); sun.shadows=LightShadows.Soft;
        sun.shadowStrength=.82f; sun.shadowBias=.045f; sun.shadowNormalBias=.35f;
        RenderSettings.sun=sun;

        // Cinematic URP post-processing. The scene remains playable if the renderer
        // ignores volumes or the device cannot afford the effects.
        var volumeObject = new GameObject("GLENT Cinematic Post FX");
        var volume = volumeObject.AddComponent<Volume>();
        volume.isGlobal = true;
        volume.priority = 1f;
        volume.profile = ScriptableObject.CreateInstance<VolumeProfile>();
        var bloom = volume.profile.Add<Bloom>(true);
        bloom.threshold.value = 1.08f;
        bloom.intensity.value = .28f;
        bloom.scatter.value = .62f;
        var color = volume.profile.Add<ColorAdjustments>(true);
        color.postExposure.value = .12f;
        color.contrast.value = 12f;
        color.saturation.value = 16f;
        var vignette = volume.profile.Add<Vignette>(true);
        vignette.intensity.value = .18f;
        vignette.smoothness.value = .55f;
        var tone = volume.profile.Add<Tonemapping>(true);
        tone.mode.value = TonemappingMode.ACES;
    }
    IEnumerator BuildWorldRoutine()
    {
        var ground=GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name="Sculpted riding field"; ground.transform.position=new Vector3(0,-.08f,48);
        ground.transform.localScale=new Vector3(18,1,22); ground.GetComponent<Renderer>().material=grass;
        Cube("Packed dirt track",new Vector3(0,.02f,48),new Vector3(8,.18f,105),dirt);
        for(int side=-1;side<=1;side+=2)
        {
            Cube("Track berm",new Vector3(side*4.15f,.22f,48),new Vector3(.35f,.42f,105),darkDirt);
            Cube("Track shoulder",new Vector3(side*5.15f,-.005f,48),new Vector3(1.7f,.08f,105),grass);
        }
        yield return null;
        for(int i=0;i<5;i++) { MakeRamp(new Vector3((i%2==0?-1:1)*1.2f,.12f,13+i*17),i%2==0?1:0); yield return null; }
        for(int i=0;i<45;i++)
        {
            float z=Random.Range(2,100), x=Random.Range(-3.6f,3.6f);
            var rut=Cube("Tire rut",new Vector3(x,.115f,z),new Vector3(.07f,.012f,Random.Range(1.2f,3f)),darkDirt);
            rut.transform.rotation=Quaternion.Euler(0,Random.Range(-4,4),0);
            if(i%9==8) yield return null;
        }
        for(int side=-1;side<=1;side+=2)
        {
            for(int i=0;i<26;i++)
            {
                float z=i*4f+1;
                if(i%2==0) MakeRock(new Vector3(side*(6.0f+Random.Range(0f,3f)),.1f+Random.Range(0,.4f),z));
                if(i%3==0) MakeTree(new Vector3(side*Random.Range(8f,14f),0,z+Random.Range(-2,2)));
                if(i%3==2) yield return null;
            }
        }
        for(int i=0;i<18;i++)
        {
            var m=GameObject.CreatePrimitive(PrimitiveType.Capsule); m.name="Distant hill";
            m.transform.position=new Vector3((i-9)*18,Random.Range(5,11),115+Random.Range(0,12));
            m.transform.localScale=new Vector3(Random.Range(12,22),Random.Range(7,14),Random.Range(9,16));
            m.GetComponent<Renderer>().material=grass; Destroy(m.GetComponent<Collider>());
            if(i%3==2) yield return null;
        }
    }
    GameObject Cube(string n,Vector3 p,Vector3 s,Material m){var o=GameObject.CreatePrimitive(PrimitiveType.Cube);o.name=n;o.transform.position=p;o.transform.localScale=s;o.GetComponent<Renderer>().material=m;return o;}
    void MakeRamp(Vector3 p,int type){
        var r=GameObject.CreatePrimitive(PrimitiveType.Cube);r.name="Dirt jump ramp";r.transform.position=p+new Vector3(0,.48f,0);r.transform.localScale=new Vector3(3.4f,.9f,4.4f);r.transform.rotation=Quaternion.Euler(-14,0,0);r.GetComponent<Renderer>().material=dirt;
        var lip=GameObject.CreatePrimitive(PrimitiveType.Cube);lip.name="Ramp crest";lip.transform.position=p+new Vector3(0,.98f,1.75f);lip.transform.localScale=new Vector3(3.3f,.12f,.35f);lip.transform.rotation=Quaternion.Euler(-14,0,0);lip.GetComponent<Renderer>().material=darkDirt;
    }
    void MakeRock(Vector3 p){var o=GameObject.CreatePrimitive(PrimitiveType.Sphere);o.name="Trackside stone";o.transform.position=p;o.transform.localScale=Vector3.one*Random.Range(.25f,.8f);o.transform.rotation=Random.rotation;o.GetComponent<Renderer>().material=rock;Destroy(o.GetComponent<Collider>());}
    void MakeTree(Vector3 p){
        var trunk=GameObject.CreatePrimitive(PrimitiveType.Cylinder);trunk.name="Pine trunk";trunk.transform.position=p+Vector3.up*1.5f;trunk.transform.localScale=new Vector3(.25f,1.6f,.25f);trunk.GetComponent<Renderer>().material=darkDirt;Destroy(trunk.GetComponent<Collider>());
        for(int j=0;j<3;j++){var crown=CreateCone("Pine foliage",p+Vector3.up*(2.4f+j*.75f),new Vector3(2.4f-j*.45f,2.2f,2.4f-j*.45f),grass);}
    }
    GameObject CreateCone(string n,Vector3 pos,Vector3 scale,Material mat){
        var go=new GameObject(n);go.transform.position=pos;go.transform.localScale=scale;
        var mesh=new Mesh();const int sides=12;var verts=new Vector3[sides+2];var tris=new int[sides*6];
        verts[0]=new Vector3(0,.5f,0);verts[1]=new Vector3(0,-.5f,0);
        for(int i=0;i<sides;i++){float a=i*Mathf.PI*2f/sides;verts[i+2]=new Vector3(Mathf.Cos(a)*.5f,-.5f,Mathf.Sin(a)*.5f);}
        for(int i=0;i<sides;i++){int k=i*6;int a=i+2,b=(i+1)%sides+2;tris[k]=0;tris[k+1]=a;tris[k+2]=b;tris[k+3]=1;tris[k+4]=b;tris[k+5]=a;}
        mesh.vertices=verts;mesh.triangles=tris;mesh.RecalculateNormals();var mf=go.AddComponent<MeshFilter>();mf.sharedMesh=mesh;var mr=go.AddComponent<MeshRenderer>();mr.material=mat;return go;
    }
    void BuildBike(){
        var bike=new GameObject("GLENT Pitbike");bike.transform.position=new Vector3(0,.9f,3);var rb=bike.AddComponent<Rigidbody>();rb.mass=112;rb.drag=.08f;rb.angularDrag=1.4f;rb.interpolation=RigidbodyInterpolation.Interpolate;rb.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;
        var collider=bike.AddComponent<CapsuleCollider>();collider.center=new Vector3(0,.48f,0);collider.radius=.42f;collider.height=1.55f;collider.direction=1;
        bike.AddComponent<GlentBikeController>();
        Part(bike.transform,"Main frame",new Vector3(0,.68f,0),new Vector3(.18f,.18f,1.05f),red,Quaternion.Euler(0,0,0));
        Part(bike.transform,"Fuel tank",new Vector3(0,1.02f,.05f),new Vector3(.52f,.34f,.62f),red,Quaternion.Euler(-8,0,0));
        Part(bike.transform,"Seat",new Vector3(0,1.22f,-.32f),new Vector3(.38f,.14f,.78f),black,Quaternion.identity);
        Part(bike.transform,"Engine",new Vector3(0,.48f,-.02f),new Vector3(.46f,.48f,.48f),metal,Quaternion.identity);
        Part(bike.transform,"Front fork",new Vector3(0,.68f,.65f),new Vector3(.12f,.95f,.12f),metal,Quaternion.Euler(-12,0,0));
        Part(bike.transform,"Handlebar",new Vector3(0,1.48f,.62f),new Vector3(1.0f,.07f,.08f),metal,Quaternion.identity);
        Part(bike.transform,"Rear swingarm",new Vector3(0,.38f,-.48f),new Vector3(.12f,.13f,.75f),metal,Quaternion.identity);
        Transform frontWheel=Wheel(bike.transform,new Vector3(0,.34f,.78f));
        Transform rearWheel=Wheel(bike.transform,new Vector3(0,.34f,-.72f));
        BuildWheelDetails(bike.transform, frontWheel, true);
        BuildWheelDetails(bike.transform, rearWheel, false);
        BuildDrivetrain(bike.transform);
        BuildSuspension(bike.transform);
        BuildCockpitAndEngine(bike.transform);
        Part(bike.transform,"Front fender",new Vector3(0,.92f,.95f),new Vector3(.42f,.09f,.65f),red,Quaternion.Euler(-10,0,0));
        Part(bike.transform,"Rear fender",new Vector3(0,.96f,-.72f),new Vector3(.42f,.08f,.5f),red,Quaternion.Euler(8,0,0));
        var rider=new GameObject("Rider");rider.transform.SetParent(bike.transform);rider.transform.localPosition=new Vector3(0,1.55f,-.1f);
        Part(rider.transform,"Rider torso",new Vector3(0,.18f,0),new Vector3(.48f,.7f,.35f),black,Quaternion.Euler(-18,0,0));
        Part(rider.transform,"Helmet",new Vector3(0,.72f,.12f),new Vector3(.42f,.43f,.42f),red,Quaternion.identity);
        Part(rider.transform,"Helmet visor",new Vector3(0,.72f,.34f),new Vector3(.32f,.12f,.08f),black,Quaternion.identity);
        for(int s=-1;s<=1;s+=2){Part(rider.transform,"Arm",new Vector3(s*.34f,.25f,.28f),new Vector3(.16f,.58f,.16f),red,Quaternion.Euler(0,0,s*32));Part(rider.transform,"Leg",new Vector3(s*.2f,-.28f,-.1f),new Vector3(.2f,.65f,.2f),black,Quaternion.Euler(-15,0,s*8));}
    }
    void Part(Transform parent,string n,Vector3 p,Vector3 s,Material m,Quaternion q){var o=GameObject.CreatePrimitive(PrimitiveType.Cube);o.name=n;o.transform.SetParent(parent);o.transform.localPosition=p;o.transform.localScale=s;o.transform.localRotation=q;o.GetComponent<Renderer>().material=m;Destroy(o.GetComponent<Collider>());}
    Transform Wheel(Transform parent,Vector3 p){
        var w=new GameObject("Knobby tire assembly");w.transform.SetParent(parent);w.transform.localPosition=p;
        var c=GameObject.CreatePrimitive(PrimitiveType.Cylinder);c.name="Rubber tire";c.transform.SetParent(w.transform);c.transform.localRotation=Quaternion.Euler(90,0,0);c.transform.localScale=new Vector3(.66f,.16f,.66f);c.GetComponent<Renderer>().material=rubber;Destroy(c.GetComponent<Collider>());
        var hub=GameObject.CreatePrimitive(PrimitiveType.Cylinder);hub.name="Wheel hub";hub.transform.SetParent(w.transform);hub.transform.localRotation=Quaternion.Euler(90,0,0);hub.transform.localScale=new Vector3(.27f,.18f,.27f);hub.GetComponent<Renderer>().material=metal;Destroy(hub.GetComponent<Collider>());
        return w.transform;
    }
    void BuildWheelDetails(Transform bike,Transform wheel,bool front){
        // Paired brake rotors, calipers and visible crossed spokes on both sides.
        for(int side=-1;side<=1;side+=2){
            float x=side*.105f;
            var rotor=GameObject.CreatePrimitive(PrimitiveType.Cylinder);rotor.name="Perforated-look brake rotor";rotor.transform.SetParent(wheel);rotor.transform.localPosition=new Vector3(0,0,side*.105f);rotor.transform.localRotation=Quaternion.Euler(90,0,0);rotor.transform.localScale=new Vector3(.38f,.025f,.38f);rotor.GetComponent<Renderer>().material=metal;Destroy(rotor.GetComponent<Collider>());
            var caliper=GameObject.CreatePrimitive(PrimitiveType.Cube);caliper.name="Brake caliper";caliper.transform.SetParent(wheel);caliper.transform.localPosition=new Vector3(.17f,.13f,side*.13f);caliper.transform.localScale=new Vector3(.13f,.19f,.09f);caliper.GetComponent<Renderer>().material=red;Destroy(caliper.GetComponent<Collider>());
            for(int i=0;i<12;i++){
                float a=i*Mathf.PI/6f;
                Vector3 a1=new Vector3(Mathf.Cos(a)*.12f,Mathf.Sin(a)*.12f,side*.075f);
                Vector3 b1=new Vector3(Mathf.Cos(a+1.05f)*.29f,Mathf.Sin(a+1.05f)*.29f,side*.075f);
                Rod(wheel,"Stainless wheel spoke",a1,b1,.018f,metal);
                Vector3 a2=new Vector3(Mathf.Cos(a+Mathf.PI)*.12f,Mathf.Sin(a+Mathf.PI)*.12f,side*.075f);
                Vector3 b2=new Vector3(Mathf.Cos(a+.35f)*.29f,Mathf.Sin(a+.35f)*.29f,side*.075f);
                Rod(wheel,"Crossed wheel spoke",a2,b2,.014f,metal);
            }
        }
        // Raised rubber tread blocks around the circumference.
        for(int i=0;i<24;i++){
            float a=i*Mathf.PI*2f/24f;
            var lug=GameObject.CreatePrimitive(PrimitiveType.Cube);lug.name="Off-road tire tread lug";lug.transform.SetParent(wheel);
            lug.transform.localPosition=new Vector3(Mathf.Sin(a)*.326f,Mathf.Cos(a)*.326f,0);
            lug.transform.localRotation=Quaternion.Euler(0,0,-a*Mathf.Rad2Deg);
            lug.transform.localScale=new Vector3(.105f,.075f,.19f);lug.GetComponent<Renderer>().material=rubber;Destroy(lug.GetComponent<Collider>());
        }
    }
    void BuildDrivetrain(Transform b){
        // Chain run and sprockets on the left side of the motorcycle.
        foreach(int side in new int[]{-1,1}){
            float x=side*.245f;
            var front=GameObject.CreatePrimitive(PrimitiveType.Cylinder);front.name="Front chain sprocket";front.transform.SetParent(b);front.transform.localPosition=new Vector3(x,.48f,-.08f);front.transform.localRotation=Quaternion.Euler(90,0,0);front.transform.localScale=new Vector3(.31f,.045f,.31f);front.GetComponent<Renderer>().material=metal;Destroy(front.GetComponent<Collider>());
            var rear=GameObject.CreatePrimitive(PrimitiveType.Cylinder);rear.name="Rear sprocket";rear.transform.SetParent(b);rear.transform.localPosition=new Vector3(x,.34f,-.72f);rear.transform.localRotation=Quaternion.Euler(90,0,0);rear.transform.localScale=new Vector3(.38f,.045f,.38f);rear.GetComponent<Renderer>().material=metal;Destroy(rear.GetComponent<Collider>());
            Rod(b,"Upper drive chain",new Vector3(x,.62f,-.1f),new Vector3(x,.51f,-.68f),.045f,black);
            Rod(b,"Lower drive chain",new Vector3(x,.34f,-.72f),new Vector3(x,.39f,-.12f),.045f,black);
        }
        Rod(b,"Exhaust header",new Vector3(.2f,.53f,.02f),new Vector3(.23f,.76f,-.53f),.09f,metal);
        Part(b,"Silencer",new Vector3(.25f,.88f,-.58f),new Vector3(.17f,.18f,.72f),metal,Quaternion.Euler(-12,0,0));
        Part(b,"Silencer end cap",new Vector3(.25f,.96f,-.91f),new Vector3(.13f,.13f,.06f),black,Quaternion.identity);
    }
    void BuildSuspension(Transform b){
        // Twin fork legs, guards and rear spring/damper.
        for(int side=-1;side<=1;side+=2){
            Vector3 top=new Vector3(side*.16f,.99f,.57f), bottom=new Vector3(side*.16f,.39f,.79f);
            Rod(b,"Front fork stanchion",top,bottom,.075f,metal);
            Part(b,"Fork lower guard",new Vector3(side*.16f,.56f,.73f),new Vector3(.13f,.43f,.16f),red,Quaternion.Euler(-12,0,0));
            Part(b,"Foot peg",new Vector3(side*.38f,.38f,-.05f),new Vector3(.24f,.07f,.13f),metal,Quaternion.identity);
        }
        Rod(b,"Rear shock body",new Vector3(.12f,.93f,-.28f),new Vector3(.12f,.43f,-.58f),.12f,metal);
        Vector3 start=new Vector3(.12f,.91f,-.28f), end=new Vector3(.12f,.45f,-.58f);
        for(int i=0;i<10;i++){
            float t0=i/10f,t1=(i+1)/10f;
            Vector3 p0=Vector3.Lerp(start,end,t0)+new Vector3(Mathf.Sin(t0*10*Mathf.PI)*.075f,0,0);
            Vector3 p1=Vector3.Lerp(start,end,t1)+new Vector3(Mathf.Sin(t1*10*Mathf.PI)*.075f,0,0);
            Rod(b,"Rear shock coil spring",p0,p1,.035f,red);
        }
    }
    void BuildCockpitAndEngine(Transform b){
        Part(b,"Left rubber grip",new Vector3(-.53f,1.48f,.62f),new Vector3(.25f,.09f,.09f),rubber,Quaternion.identity);
        Part(b,"Right rubber grip",new Vector3(.53f,1.48f,.62f),new Vector3(.25f,.09f,.09f),rubber,Quaternion.identity);
        Part(b,"Radiator left",new Vector3(-.27f,.83f,.14f),new Vector3(.08f,.36f,.3f),black,Quaternion.identity);
        Part(b,"Radiator right",new Vector3(.27f,.83f,.14f),new Vector3(.08f,.36f,.3f),black,Quaternion.identity);
        for(int i=0;i<5;i++){
            Part(b,"Radiator cooling fin",new Vector3(-.316f,.69f+i*.065f,.14f),new Vector3(.025f,.025f,.27f),metal,Quaternion.identity);
            Part(b,"Radiator cooling fin",new Vector3(.316f,.69f+i*.065f,.14f),new Vector3(.025f,.025f,.27f),metal,Quaternion.identity);
        }
        Part(b,"Left engine cover",new Vector3(-.25f,.48f,-.04f),new Vector3(.07f,.32f,.34f),metal,Quaternion.identity);
        Part(b,"Right engine cover",new Vector3(.25f,.48f,-.04f),new Vector3(.07f,.32f,.34f),metal,Quaternion.identity);
    }
    void Rod(Transform parent,string n,Vector3 a,Vector3 b,float radius,Material mat){
        var o=GameObject.CreatePrimitive(PrimitiveType.Cylinder);o.name=n;o.transform.SetParent(parent);
        Vector3 d=b-a;o.transform.localPosition=(a+b)*.5f;o.transform.localRotation=Quaternion.FromToRotation(Vector3.up,d.normalized);
        o.transform.localScale=new Vector3(radius,d.magnitude*.5f,radius);o.GetComponent<Renderer>().material=mat;Destroy(o.GetComponent<Collider>());
    }
}
