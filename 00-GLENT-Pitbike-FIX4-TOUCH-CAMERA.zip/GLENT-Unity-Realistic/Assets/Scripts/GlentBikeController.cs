using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class GlentBikeController : MonoBehaviour
{
    [Header("Powertrain")]
    public float acceleration = 30f;
    public float maxSpeed = 25f;
    public float brakePower = 22f;
    [Header("Handling")]
    public float steering = 78f;
    public float leanTorque = 5.5f;
    public float lateralGrip = 4.8f;
    public float airControl = 2.8f;
    public float downforce = 2.2f;

    Rigidbody rb;
    Transform[] visualWheels;
    float throttle, steer;
    bool brake, trick;
    ParticleSystem dust;
    float dustTimer;
    public float Speed => rb ? rb.velocity.magnitude * 3.6f : 0f;
    public bool IsGrounded => Physics.SphereCast(transform.position + Vector3.up * .25f, .22f, Vector3.down, out _, 1.05f, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore);

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        var wheels = new System.Collections.Generic.List<Transform>();
        foreach (Transform child in GetComponentsInChildren<Transform>(true))
            if (child.name == "Knobby tire assembly") wheels.Add(child);
        visualWheels = wheels.ToArray();
        rb.centerOfMass = new Vector3(0, -.22f, -.08f);
        rb.maxAngularVelocity = 8f;
        CreateDustSystem();
    }

    void Update()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        steer = Mathf.Abs(h) > .05f ? h : GlentMobileHUD.Steer;
        throttle = Mathf.Abs(v) > .05f ? Mathf.Max(0, v) : GlentMobileHUD.Throttle;
        brake = Input.GetKey(KeyCode.Space) || GlentMobileHUD.Brake;
        trick = Input.GetKey(KeyCode.LeftShift) || GlentMobileHUD.Trick;
    }

    void FixedUpdate()
    {
        bool grounded = IsGrounded;
        UpdateDust(grounded);
        Vector3 localVelocity = transform.InverseTransformDirection(rb.velocity);
        float forwardSpeed = localVelocity.z;
        // Spin the detailed visual wheel assemblies with the actual bike velocity.
        float wheelDegrees = forwardSpeed * Mathf.Rad2Deg * Time.fixedDeltaTime / .33f;
        if (visualWheels != null)
            for (int i = 0; i < visualWheels.Length; i++)
                if (visualWheels[i]) visualWheels[i].Rotate(Vector3.right, wheelDegrees, Space.Self);

        if (grounded)
        {
            if (throttle > 0f && forwardSpeed < maxSpeed)
                rb.AddForce(transform.forward * throttle * acceleration, ForceMode.Acceleration);

            if (brake)
                rb.AddForce(-transform.forward * brakePower, ForceMode.Acceleration);

            // Reduce unrealistic sideways skating while retaining controlled dirt-bike slides.
            Vector3 lateral = transform.right * localVelocity.x;
            rb.AddForce(-lateral * lateralGrip, ForceMode.Acceleration);

            float speedFactor = Mathf.Clamp01(forwardSpeed / 2.5f);
            rb.AddTorque(Vector3.up * steer * steering * speedFactor * .012f, ForceMode.Acceleration);

            // Lean into turns, then let the bike naturally recover upright.
            float targetLean = -steer * Mathf.Clamp01(forwardSpeed / 7f) * 22f;
            float currentLean = Vector3.SignedAngle(transform.up, Vector3.up, transform.forward);
            rb.AddTorque(transform.forward * ((targetLean - currentLean) * leanTorque * .035f), ForceMode.Acceleration);
            rb.AddForce(-transform.up * downforce * Mathf.Max(0f, forwardSpeed), ForceMode.Acceleration);

            // Gentle self-righting keeps the arcade prototype controllable on touch screens.
            Vector3 uprightError = Vector3.Cross(transform.up, Vector3.up);
            rb.AddTorque(uprightError * 2.2f, ForceMode.Acceleration);
            Vector3 angularLocal = transform.InverseTransformDirection(rb.angularVelocity);
            rb.AddTorque(transform.TransformDirection(new Vector3(-angularLocal.x * .55f, 0f, -angularLocal.z * .7f)), ForceMode.Acceleration);
        }
        else
        {
            float multiplier = trick ? 1.8f : 1f;
            rb.AddTorque(transform.right * (-steer * airControl * multiplier), ForceMode.Acceleration);
            rb.AddTorque(transform.forward * (-throttle * airControl), ForceMode.Acceleration);
            // Small pitch trim makes long jumps easier without removing player control.
            rb.AddTorque(Vector3.Cross(transform.forward, Vector3.forward) * .28f, ForceMode.Acceleration);
        }

        Vector3 horizontal = new Vector3(rb.velocity.x, 0f, rb.velocity.z);
        if (horizontal.magnitude > maxSpeed)
        {
            Vector3 limited = horizontal.normalized * maxSpeed;
            rb.velocity = new Vector3(limited.x, rb.velocity.y, limited.z);
        }
    }


    void CreateDustSystem()
    {
        var dustObject = new GameObject("Rear wheel dirt particles");
        dustObject.transform.SetParent(transform, false);
        dustObject.transform.localPosition = new Vector3(0f, .28f, -.88f);
        dust = dustObject.AddComponent<ParticleSystem>();
        var main = dust.main;
        main.loop = false;
        main.playOnAwake = false;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = 260;
        main.startLifetime = new ParticleSystem.MinMaxCurve(.35f, .8f);
        main.startSpeed = new ParticleSystem.MinMaxCurve(.4f, 2.2f);
        main.startSize = new ParticleSystem.MinMaxCurve(.08f, .24f);
        main.startColor = new ParticleSystem.MinMaxGradient(new Color(.24f,.16f,.10f,.42f), new Color(.48f,.34f,.22f,.25f));
        var emission = dust.emission;
        emission.enabled = false;
        var shape = dust.shape;
        shape.enabled = true;
        shape.shapeType = ParticleSystemShapeType.Cone;
        shape.angle = 24f;
        shape.radius = .12f;
        var velocity = dust.velocityOverLifetime;
        velocity.enabled = true;
        velocity.space = ParticleSystemSimulationSpace.World;
        velocity.y = new ParticleSystem.MinMaxCurve(.25f, 1.1f);
        var color = dust.colorOverLifetime;
        color.enabled = true;
        Gradient gradient = new Gradient();
        gradient.SetKeys(
            new[] { new GradientColorKey(new Color(.38f,.25f,.14f),0f), new GradientColorKey(new Color(.3f,.22f,.16f),1f) },
            new[] { new GradientAlphaKey(.42f,0f), new GradientAlphaKey(0f,1f) });
        color.color = gradient;
        var renderer = dust.GetComponent<ParticleSystemRenderer>();
        Shader particleShader = Shader.Find("Universal Render Pipeline/Particles/Unlit");
        if (particleShader == null) particleShader = Shader.Find("Particles/Standard Unlit");
        if (particleShader != null) renderer.material = new Material(particleShader);
    }

    void UpdateDust(bool grounded)
    {
        if (!dust) return;
        float speed = rb ? rb.velocity.magnitude : 0f;
        if (!grounded || speed < 2.5f) return;
        dustTimer += Time.fixedDeltaTime;
        if (dustTimer >= .045f)
        {
            dustTimer = 0f;
            int count = Mathf.Clamp(Mathf.RoundToInt(speed * .18f), 1, 5);
            var emit = new ParticleSystem.EmitParams();
            emit.position = transform.TransformPoint(new Vector3(0f,.27f,-.9f));
            emit.velocity = -transform.forward * Mathf.Clamp(speed * .16f, .7f, 4f) + Vector3.up * .35f;
            dust.Emit(emit, count);
        }
    }

    public void ResetBike()
    {
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        transform.SetPositionAndRotation(new Vector3(0, 1.25f, 3), Quaternion.identity);
        Physics.SyncTransforms();
    }
}
