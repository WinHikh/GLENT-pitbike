using UnityEngine;

/// <summary>
/// GLENT's red/black race HUD. Touch controls track their owning finger IDs,
/// so a finger can slide outside a button without leaving the input stuck.
/// </summary>
public class GlentMobileHUD : MonoBehaviour
{
    public static float Throttle, Steer;
    public static bool Brake, Trick;

    GlentBikeController bike;
    bool paused;
    int throttleFinger = -1, brakeFinger = -1, leftFinger = -1, rightFinger = -1, trickFinger = -1;
    bool mouseThrottle, mouseBrake, mouseLeft, mouseRight, mouseTrick;
    GUIStyle titleStyle, statStyle, speedStyle, buttonStyle, smallStyle, pauseStyle;
    Texture2D blackTex, darkTex, redTex, whiteTex, panelTex;

    const float RefWidth = 900f;
    float UiScale => Mathf.Clamp(Screen.width / RefWidth, .65f, 1.5f);
    float UiWidth => Screen.width / UiScale;
    float UiHeight => Screen.height / UiScale;

    void Start()
    {
        blackTex = MakeTex(new Color(.018f,.02f,.026f,.96f));
        darkTex = MakeTex(new Color(.075f,.078f,.085f,.94f));
        redTex = MakeTex(new Color(.78f,.015f,.035f,.98f));
        whiteTex = MakeTex(new Color(.92f,.91f,.88f,.98f));
        panelTex = MakeTex(new Color(.025f,.028f,.035f,.84f));

        titleStyle = new GUIStyle(GUI.skin.label) { fontSize=27, fontStyle=FontStyle.Bold, alignment=TextAnchor.MiddleLeft };
        titleStyle.normal.textColor=Color.white;
        statStyle = new GUIStyle(GUI.skin.label) { fontSize=15, fontStyle=FontStyle.Bold, alignment=TextAnchor.MiddleLeft };
        statStyle.normal.textColor=new Color(.82f,.83f,.85f);
        speedStyle = new GUIStyle(GUI.skin.label) { fontSize=34, fontStyle=FontStyle.Bold, alignment=TextAnchor.MiddleRight };
        speedStyle.normal.textColor=Color.white;
        buttonStyle = new GUIStyle(GUI.skin.label) { fontSize=19, fontStyle=FontStyle.Bold, alignment=TextAnchor.MiddleCenter };
        buttonStyle.normal.textColor=Color.white;
        smallStyle = new GUIStyle(GUI.skin.label) { fontSize=12, fontStyle=FontStyle.Bold, alignment=TextAnchor.MiddleCenter };
        smallStyle.normal.textColor=new Color(1f,.22f,.27f);
        pauseStyle = new GUIStyle(GUI.skin.button) { fontSize=14, fontStyle=FontStyle.Bold };
    }

    Texture2D MakeTex(Color c)
    {
        var t = new Texture2D(1,1,TextureFormat.RGBA32,false);
        t.SetPixel(0,0,c); t.Apply(); return t;
    }

    void Update()
    {
        if (!bike) bike=FindObjectOfType<GlentBikeController>();
        float s=UiScale, w=UiWidth, h=UiHeight, y=h-145f;
        Rect brakeR=new Rect(28,y,130,105);
        Rect trickR=new Rect(175,y,130,105);
        Rect throttleR=new Rect(w-320,y-118,275,100);
        Rect leftR=new Rect(w-320,y,130,105);
        Rect rightR=new Rect(w-175,y,130,105);

        // Release all controls when the application loses focus or is paused.
        if (paused || !Application.isFocused)
        {
            ReleaseAll();
            return;
        }

        foreach (Touch t in Input.touches)
        {
            Vector2 p=new Vector2(t.position.x/s,(Screen.height-t.position.y)/s);
            if (t.phase==TouchPhase.Began)
            {
                if (brakeFinger==-1 && brakeR.Contains(p)) brakeFinger=t.fingerId;
                else if (trickFinger==-1 && trickR.Contains(p)) trickFinger=t.fingerId;
                else if (throttleFinger==-1 && throttleR.Contains(p)) throttleFinger=t.fingerId;
                else if (leftFinger==-1 && leftR.Contains(p)) leftFinger=t.fingerId;
                else if (rightFinger==-1 && rightR.Contains(p)) rightFinger=t.fingerId;
            }
            if (t.phase==TouchPhase.Ended || t.phase==TouchPhase.Canceled)
            {
                if (brakeFinger==t.fingerId) brakeFinger=-1;
                if (trickFinger==t.fingerId) trickFinger=-1;
                if (throttleFinger==t.fingerId) throttleFinger=-1;
                if (leftFinger==t.fingerId) leftFinger=-1;
                if (rightFinger==t.fingerId) rightFinger=-1;
            }
        }

#if UNITY_EDITOR || UNITY_STANDALONE
        // Keyboard remains available when testing in the Unity Editor.
        mouseThrottle=Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow);
        mouseBrake=Input.GetKey(KeyCode.Space);
        mouseLeft=Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow);
        mouseRight=Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow);
        mouseTrick=Input.GetKey(KeyCode.LeftShift);
#endif
        Throttle=(throttleFinger!=-1 || mouseThrottle)?1f:0f;
        Brake=brakeFinger!=-1 || mouseBrake;
        Trick=trickFinger!=-1 || mouseTrick;
        Steer=leftFinger!=-1 || mouseLeft ? -1f : rightFinger!=-1 || mouseRight ? 1f : 0f;
    }

    void OnGUI()
    {
        if (titleStyle==null) return;
        GUI.matrix=Matrix4x4.TRS(Vector3.zero,Quaternion.identity,Vector3.one*UiScale);
        float w=UiWidth, h=UiHeight;

        // Angular black/red title plate inspired by the supplied GLENT artwork.
        GUI.DrawTexture(new Rect(14,12,365,92),blackTex);
        GUI.DrawTexture(new Rect(14,12,7,92),redTex);
        GUI.DrawTexture(new Rect(30,21,4,62),redTex);
        GUI.Label(new Rect(45,17,310,40),"GLENT",titleStyle);
        GUI.Label(new Rect(47,54,300,27),"CROWN SERIES  /  PITBIKE",smallStyle);
        int score=GlentGameManager.Instance!=null?GlentGameManager.Instance.Score:0;
        int best=GlentGameManager.Instance!=null?GlentGameManager.Instance.Best:0;
        GUI.DrawTexture(new Rect(390,20,245,68),panelTex);
        GUI.Label(new Rect(405,22,220,27),"SCORE  "+score.ToString("000000"),statStyle);
        GUI.Label(new Rect(405,51,220,25),"BEST     "+best.ToString("000000"),statStyle);

        GUI.DrawTexture(new Rect(w-190,12,176,92),blackTex);
        GUI.DrawTexture(new Rect(w-190,12,176,5),redTex);
        GUI.Label(new Rect(w-178,17,150,48),(bike?bike.Speed:0).ToString("000")+"",speedStyle);
        GUI.Label(new Rect(w-178,63,150,25),"KM/H",smallStyle);

        if (GUI.Button(new Rect(w-112,116,98,38),paused?"RIDE":"PAUSE",pauseStyle))
        {
            paused=!paused; Time.timeScale=paused?0f:1f;
            if(paused) ReleaseAll();
        }

        float y=h-145f;
        DrawControl(new Rect(28,y,130,105),"BRAKE",Brake,true);
        DrawControl(new Rect(175,y,130,105),"TRICK",Trick,false);
        DrawControl(new Rect(w-320,y-118,275,100),"THROTTLE",Throttle>0.1f,true);
        DrawControl(new Rect(w-320,y,130,105),"LEFT",Steer<-.1f,false);
        DrawControl(new Rect(w-175,y,130,105),"RIGHT",Steer>.1f,false);

        GUI.Label(new Rect(w*.36f,112,w*.28f,30),"DRAG TO LOOK",smallStyle);
        if(paused)
        {
            GUI.DrawTexture(new Rect(w*.5f-170,h*.5f-65,340,130),blackTex);
            GUI.DrawTexture(new Rect(w*.5f-170,h*.5f-65,340,6),redTex);
            GUI.Label(new Rect(w*.5f-150,h*.5f-38,300,65),"RIDE PAUSED",titleStyle);
        }
    }

    void DrawControl(Rect r,string label,bool active,bool accent)
    {
        GUI.DrawTexture(r,active?redTex:darkTex);
        GUI.DrawTexture(new Rect(r.x,r.y,r.width,5),accent?redTex:whiteTex);
        GUI.Label(new Rect(r.x+4,r.y+10,r.width-8,r.height-20),label,buttonStyle);
    }

    void ReleaseAll()
    {
        throttleFinger=brakeFinger=leftFinger=rightFinger=trickFinger=-1;
        mouseThrottle=mouseBrake=mouseLeft=mouseRight=mouseTrick=false;
        Throttle=Steer=0; Brake=Trick=false;
    }

    void OnApplicationFocus(bool focus) { if(!focus) ReleaseAll(); }
    void OnDisable() { Time.timeScale=1f; ReleaseAll(); }
}
